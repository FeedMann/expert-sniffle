#!/usr/bin/env python3
"""
godot_ctex.py - Godot 4 CompressedTexture2D (.ctex) 1:1 Importer & TGA Converter

This script replicates the exact C++ behavior of:
  - editor/import/resource_importer_texture.cpp (ResourceImporterTexture::_save_ctex & save_to_ctex_format)
  - modules/etcpak/image_compress_etcpak.cpp
  - scene/resources/compressed_texture.cpp
  - core/io/image.cpp

File Layout for .ctex (Godot Streamable Texture 2D):
  [0..3]   Magic 'GST2'
  [4..7]   uint32 version (FORMAT_VERSION = 1)
  [8..11]  uint32 original_width
  [12..15] uint32 original_height
  [16..19] uint32 flags (bit 23 = FORMAT_BIT_HAS_MIPMAPS)
  [20..23] uint32 limit_mipmap (default 0)
  [24..35] uint32 reserved[3] (0, 0, 0)
  -- Payload Header --
  [36..39] uint32 data_format (0=IMAGE, 1=PNG, 2=WEBP, 3=BASISU)
  [40..41] uint16 width
  [42..43] uint16 height
  [44..47] uint32 mipmap_count
  [48..51] uint32 format (Godot Image::Format enum)
  -- Payload Data --
  [52..]   For DATA_FORMAT_IMAGE: raw buffer of compressed or uncompressed blocks.
           For DATA_FORMAT_WEBP/PNG: for each mipmap: uint32 chunk_size + chunk_bytes.
"""

import sys
import os
import struct
import math
import io
import argparse
from typing import Tuple, List, Optional
import numpy as np
from PIL import Image

# Check for etcpak
try:
    import etcpak
    HAS_ETCPAK = True
except ImportError:
    HAS_ETCPAK = False

# Godot 4 Constants
MAGIC = b"GST2"
FORMAT_VERSION = 1

# Format Bits
FORMAT_BIT_HAS_MIPMAPS = 1 << 23
FORMAT_BIT_DETECT_3D = 1 << 24
FORMAT_BIT_DETECT_NORMAL = 1 << 26
FORMAT_BIT_DETECT_ROUGHNESS = 1 << 27

# CompressedTexture2D::DataFormat
DATA_FORMAT_IMAGE = 0
DATA_FORMAT_PNG = 1
DATA_FORMAT_WEBP = 2
DATA_FORMAT_BASIS_UNIVERSAL = 3

# Godot Image::Format Enum (core/io/image.h)
FORMAT_L8 = 0
FORMAT_LA8 = 1
FORMAT_R8 = 2
FORMAT_RG8 = 3
FORMAT_RGB8 = 4
FORMAT_RGBA8 = 5
FORMAT_RGBA4444 = 6
FORMAT_RGB565 = 7
FORMAT_RF = 8
FORMAT_RGF = 9
FORMAT_RGBF = 10
FORMAT_RGBAF = 11
FORMAT_RH = 12
FORMAT_RGH = 13
FORMAT_RGBH = 14
FORMAT_RGBAH = 15
FORMAT_RGBE9995 = 16
FORMAT_DXT1 = 17       # BC1
FORMAT_DXT3 = 18       # BC2
FORMAT_DXT5 = 19       # BC3
FORMAT_RGTC_R = 20     # BC4
FORMAT_RGTC_RG = 21    # BC5
FORMAT_BPTC_RGBA = 22   # BC7
FORMAT_BPTC_RGBF = 23   # BC6 Signed
FORMAT_BPTC_RGBFU = 24  # BC6 Unsigned
FORMAT_ETC = 25        # ETC1
FORMAT_ETC2_R11 = 26
FORMAT_ETC2_R11S = 27
FORMAT_ETC2_RG11 = 28
FORMAT_ETC2_RG11S = 29
FORMAT_ETC2_RGB8 = 30
FORMAT_ETC2_RGBA8 = 31
FORMAT_ETC2_RGB8A1 = 32
FORMAT_ETC2_RA_AS_RG = 33
FORMAT_DXT5_RA_AS_RG = 34
FORMAT_ASTC_4x4 = 35
FORMAT_ASTC_4x4_HDR = 36
FORMAT_ASTC_8x8 = 37
FORMAT_ASTC_8x8_HDR = 38

FORMAT_NAMES = {
    FORMAT_RGB8: "RGB8",
    FORMAT_RGBA8: "RGBA8",
    FORMAT_DXT1: "DXT1 (BC1)",
    FORMAT_DXT5: "DXT5 (BC3)",
    FORMAT_ETC2_RGB8: "ETC2_RGB8",
    FORMAT_ETC2_RGBA8: "ETC2_RGBA8",
    FORMAT_ASTC_4x4: "ASTC_4x4",
}


def compute_mipmap_count(width: int, height: int) -> int:
    """Godot calculates required mipmaps as floor(log2(max(w, h)))."""
    return int(math.floor(math.log2(max(width, height))))


def pad_and_smear(src_rgba: np.ndarray, dest_w: int, dest_h: int) -> np.ndarray:
    """
    Pad texture to nearest multiple of 4x4 by smearing edge texels.
    Matches Godot modules/etcpak/image_compress_etcpak.cpp lines 225-248.
    """
    src_h, src_w, _ = src_rgba.shape
    if src_w == dest_w and src_h == dest_h:
        return src_rgba

    padded = np.zeros((dest_h, dest_w, 4), dtype=np.uint8)
    padded[:src_h, :src_w] = src_rgba

    # Smear in X
    for x in range(src_w, dest_w):
        padded[:src_h, x] = padded[:src_h, x - 1]

    # Smear in Y
    for y in range(src_h, dest_h):
        padded[y, :] = padded[y - 1, :]

    return padded


def generate_mipmaps_chain(img: Image.Image) -> List[Image.Image]:
    """Generate mipmap chain down to 1x1, matching Godot's mipmap generation."""
    mips = [img]
    w, h = img.size
    while w > 1 or h > 1:
        w = max(1, w >> 1)
        h = max(1, h >> 1)
        # Godot uses box filter for downsampling
        mips.append(img.resize((w, h), Image.Resampling.BOX))
    return mips


def compress_image_etc2(
    img: Image.Image,
    has_alpha: bool,
    with_mipmaps: bool = True
) -> Tuple[int, bytes, List[Tuple[int, int, int]]]:
    """
    Compress an image to ETC2 using etcpak.
    Replicates Godot's _compress_etc2 in modules/etcpak/image_compress_etcpak.cpp.
    Note: ETCPAK expects BGRA8 for ETC formats!
    """
    if not HAS_ETCPAK:
        raise RuntimeError("etcpak is required for ETC2 compression. Run `pip install etcpak`.")

    w, h = img.size
    # Godot aligns top-level dimension to 4x4
    aligned_w = (w + 3) & ~3
    aligned_h = (h + 3) & ~3
    if aligned_w != w or aligned_h != h:
        img = img.resize((aligned_w, aligned_h), Image.Resampling.NEAREST)

    chain = generate_mipmaps_chain(img) if with_mipmaps else [img]

    godot_format = FORMAT_ETC2_RGBA8 if has_alpha else FORMAT_ETC2_RGB8
    compressed_payload = bytearray()
    levels_info = []

    for level, mip_img in enumerate(chain):
        mip_w, mip_h = mip_img.size
        dest_mip_w = (mip_w + 3) & ~3
        dest_mip_h = (mip_h + 3) & ~3

        arr_rgba = np.array(mip_img.convert("RGBA"), dtype=np.uint8)
        arr_padded = pad_and_smear(arr_rgba, dest_mip_w, dest_mip_h)

        # Godot convert_rgba8_to_bgra8() before passing to etcpak
        arr_bgra = arr_padded[:, :, [2, 1, 0, 3]].copy()
        raw_bgra = arr_bgra.tobytes()

        if has_alpha:
            block_data = etcpak.compress_etc2_rgba(raw_bgra, dest_mip_w, dest_mip_h)
        else:
            block_data = etcpak.compress_etc2_rgb(raw_bgra, dest_mip_w, dest_mip_h)

        levels_info.append((mip_w, mip_h, len(block_data)))
        compressed_payload.extend(block_data)

    return godot_format, bytes(compressed_payload), levels_info


def compress_image_dxt(
    img: Image.Image,
    has_alpha: bool,
    with_mipmaps: bool = True
) -> Tuple[int, bytes, List[Tuple[int, int, int]]]:
    """
    Compress an image to DXT1 (BC1) or DXT5 (BC3) using etcpak.
    Replicates Godot's _compress_bc in modules/etcpak/image_compress_etcpak.cpp.
    """
    if not HAS_ETCPAK:
        raise RuntimeError("etcpak is required for DXT compression. Run `pip install etcpak`.")

    w, h = img.size
    aligned_w = (w + 3) & ~3
    aligned_h = (h + 3) & ~3
    if aligned_w != w or aligned_h != h:
        img = img.resize((aligned_w, aligned_h), Image.Resampling.NEAREST)

    chain = generate_mipmaps_chain(img) if with_mipmaps else [img]

    godot_format = FORMAT_DXT5 if has_alpha else FORMAT_DXT1
    compressed_payload = bytearray()
    levels_info = []

    for level, mip_img in enumerate(chain):
        mip_w, mip_h = mip_img.size
        dest_mip_w = (mip_w + 3) & ~3
        dest_mip_h = (mip_h + 3) & ~3

        arr_rgba = np.array(mip_img.convert("RGBA"), dtype=np.uint8)
        arr_padded = pad_and_smear(arr_rgba, dest_mip_w, dest_mip_h)
        raw_rgba = arr_padded.tobytes()

        if has_alpha:
            block_data = etcpak.compress_to_dxt5(raw_rgba, dest_mip_w, dest_mip_h)
        else:
            block_data = etcpak.compress_to_dxt1(raw_rgba, dest_mip_w, dest_mip_h)

        levels_info.append((mip_w, mip_h, len(block_data)))
        compressed_payload.extend(block_data)

    return godot_format, bytes(compressed_payload), levels_info


def compress_image_webp(
    img: Image.Image,
    lossless: bool = True,
    quality: int = 80,
    with_mipmaps: bool = False
) -> Tuple[int, bytes, List[Tuple[int, int, int]]]:
    """
    Compress image to WebP (Lossless or Lossy), matching Godot save_to_ctex_format.
    Format stores each mipmap chunk prefixed with uint32 data_size.
    """
    has_alpha = img.mode == "RGBA" or "A" in img.getbands()
    godot_format = FORMAT_RGBA8 if has_alpha else FORMAT_RGB8
    chain = generate_mipmaps_chain(img) if with_mipmaps else [img]

    payload = bytearray()
    levels_info = []

    for mip_img in chain:
        mip_w, mip_h = mip_img.size
        buf = io.BytesIO()
        if lossless:
            mip_img.save(buf, format="WEBP", lossless=True)
        else:
            mip_img.save(buf, format="WEBP", quality=quality)
        chunk = buf.getvalue()
        # Godot writes uint32 chunk size followed by chunk buffer
        payload.extend(struct.pack("<I", len(chunk)))
        payload.extend(chunk)
        levels_info.append((mip_w, mip_h, len(chunk)))

    return godot_format, bytes(payload), levels_info


def compress_image_uncompressed(
    img: Image.Image,
    with_mipmaps: bool = False
) -> Tuple[int, bytes, List[Tuple[int, int, int]]]:
    """Store raw uncompressed RGBA8 / RGB8 bytes in CTEX."""
    has_alpha = img.mode == "RGBA" or "A" in img.getbands()
    godot_format = FORMAT_RGBA8 if has_alpha else FORMAT_RGB8
    chain = generate_mipmaps_chain(img) if with_mipmaps else [img]

    payload = bytearray()
    levels_info = []

    for mip_img in chain:
        mip_w, mip_h = mip_img.size
        target_mode = "RGBA" if has_alpha else "RGB"
        raw = mip_img.convert(target_mode).tobytes()
        payload.extend(raw)
        levels_info.append((mip_w, mip_h, len(raw)))

    return godot_format, bytes(payload), levels_info


def encode_to_ctex(
    input_path: str,
    output_path: str,
    mode: str = "etc2",
    mipmaps: bool = True,
    quality: int = 80
) -> dict:
    """
    Encodes an image to Godot 4 .ctex format 1:1.
    mode can be:
      - 'etc2': Godot Mobile/Web VRAM compressed (ETC2_RGB8 or ETC2_RGBA8)
      - 's3tc' or 'dxt': Godot Desktop/Web VRAM compressed (DXT1 or DXT5)
      - 'lossless': Godot Lossless WebP
      - 'lossy': Godot Lossy WebP
      - 'uncompressed': Godot VRAM uncompressed (RGBA8/RGB8)
    """
    img = Image.open(input_path)
    orig_w, orig_h = img.size

    # Check alpha presence
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        img_rgba = img.convert("RGBA")
        alpha_channel = np.array(img_rgba)[:, :, 3]
        has_alpha = np.any(alpha_channel < 255)
    else:
        img_rgba = img.convert("RGBA")
        has_alpha = False

    data_format = DATA_FORMAT_IMAGE
    flags = 0
    if mipmaps:
        flags |= FORMAT_BIT_HAS_MIPMAPS

    if mode == "etc2":
        data_format = DATA_FORMAT_IMAGE
        godot_format, payload, levels = compress_image_etc2(img_rgba, has_alpha, mipmaps)
    elif mode in ("s3tc", "dxt"):
        data_format = DATA_FORMAT_IMAGE
        godot_format, payload, levels = compress_image_dxt(img_rgba, has_alpha, mipmaps)
    elif mode == "lossless":
        data_format = DATA_FORMAT_WEBP
        godot_format, payload, levels = compress_image_webp(img_rgba, lossless=True, with_mipmaps=mipmaps)
    elif mode == "lossy":
        data_format = DATA_FORMAT_WEBP
        godot_format, payload, levels = compress_image_webp(img_rgba, lossless=False, quality=quality, with_mipmaps=mipmaps)
    elif mode == "uncompressed":
        data_format = DATA_FORMAT_IMAGE
        godot_format, payload, levels = compress_image_uncompressed(img_rgba, with_mipmaps=mipmaps)
    else:
        raise ValueError(f"Unknown compression mode: {mode}")

    aligned_w, aligned_h = levels[0][0], levels[0][1]
    mipmap_count = len(levels) - 1 if mipmaps else 0

    # Build Header 1:1 with Godot _save_ctex
    header = bytearray()
    header.extend(MAGIC)  # 'G', 'S', 'T', '2'
    header.extend(struct.pack("<I", FORMAT_VERSION))  # uint32 version = 1
    header.extend(struct.pack("<I", orig_w))          # uint32 original_width
    header.extend(struct.pack("<I", orig_h))          # uint32 original_height
    header.extend(struct.pack("<I", flags))           # uint32 flags
    header.extend(struct.pack("<I", 0))               # uint32 limit_mipmap
    header.extend(struct.pack("<III", 0, 0, 0))       # uint32 reserved[3]

    # Build Payload Header 1:1 with save_to_ctex_format
    payload_header = bytearray()
    payload_header.extend(struct.pack("<I", data_format))   # uint32 data_format
    payload_header.extend(struct.pack("<H", aligned_w))     # uint16 width
    payload_header.extend(struct.pack("<H", aligned_h))     # uint16 height
    payload_header.extend(struct.pack("<I", mipmap_count))  # uint32 mipmap_count
    payload_header.extend(struct.pack("<I", godot_format))  # uint32 format (Image::Format)

    total_data = header + payload_header + payload

    with open(output_path, "wb") as f:
        f.write(total_data)

    info = {
        "output_path": output_path,
        "file_size": len(total_data),
        "header_size": len(header) + len(payload_header),
        "payload_size": len(payload),
        "orig_width": orig_w,
        "orig_height": orig_h,
        "stored_width": aligned_w,
        "stored_height": aligned_h,
        "format_id": godot_format,
        "format_name": FORMAT_NAMES.get(godot_format, f"Format_{godot_format}"),
        "data_format": data_format,
        "mipmap_count": mipmap_count,
        "levels": levels,
        "has_alpha": has_alpha,
    }
    return info


def save_to_tga(input_path: str, output_path: str) -> dict:
    """
    Saves image to uncompressed Truevision TGA (Type 2, 24-bit or 32-bit).
    This represents the baseline uncompressed texture commonly loaded in web / game engines.
    """
    img = Image.open(input_path)
    orig_w, orig_h = img.size

    # Check if alpha is needed
    if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
        img_conv = img.convert("RGBA")
        arr = np.array(img_conv)
        has_alpha = np.any(arr[:, :, 3] < 255)
    else:
        has_alpha = False
        img_conv = img.convert("RGB")
        arr = np.array(img_conv)

    bpp = 32 if has_alpha else 24
    descriptor = 0x20  # Top-to-bottom pixel order

    # 18-byte TGA Header
    header = bytearray(18)
    header[0] = 0           # ID length = 0
    header[1] = 0           # Color map type = 0
    header[2] = 2           # Image type = 2 (Uncompressed true-color)
    # Color map spec (5 bytes): 0
    header[8:10] = struct.pack("<H", 0)       # X-origin
    header[10:12] = struct.pack("<H", 0)      # Y-origin
    header[12:14] = struct.pack("<H", orig_w) # Width
    header[14:16] = struct.pack("<H", orig_h) # Height
    header[16] = bpp                          # Bits per pixel
    header[17] = descriptor                   # Descriptor

    # TGA stores pixels in BGR(A) order
    if has_alpha:
        bgra = arr[:, :, [2, 1, 0, 3]].tobytes()
        pixel_data = bgra
    else:
        bgr = arr[:, :, [2, 1, 0]].tobytes()
        pixel_data = bgr

    total_data = header + pixel_data
    with open(output_path, "wb") as f:
        f.write(total_data)

    return {
        "output_path": output_path,
        "file_size": len(total_data),
        "width": orig_w,
        "height": orig_h,
        "bpp": bpp,
        "has_alpha": has_alpha,
        "nominal_vram": orig_w * orig_h * (4 if has_alpha else 3),
        "nominal_vram_with_mips": int(orig_w * orig_h * (4 if has_alpha else 3) * 1.333333),
    }


def inspect_ctex(path: str) -> dict:
    """Reads and unpacks Godot .ctex header."""
    with open(path, "rb") as f:
        data = f.read()

    if len(data) < 52:
        raise ValueError("File is too small to be a valid .ctex file")

    magic = data[0:4]
    if magic != MAGIC:
        raise ValueError(f"Invalid magic: {magic}, expected GST2")

    version, orig_w, orig_h, flags, limit_mipmap, r1, r2, r3 = struct.unpack("<IIIIIIII", data[4:36])
    data_format, width, height, mipmap_count, godot_format = struct.unpack("<IHHII", data[36:52])

    has_mips = bool(flags & FORMAT_BIT_HAS_MIPMAPS)

    info = {
        "file_size": len(data),
        "version": version,
        "orig_width": orig_w,
        "orig_height": orig_h,
        "stored_width": width,
        "stored_height": height,
        "flags": flags,
        "has_mips_flag": has_mips,
        "limit_mipmap": limit_mipmap,
        "data_format": data_format,
        "mipmap_count": mipmap_count,
        "format_id": godot_format,
        "format_name": FORMAT_NAMES.get(godot_format, f"Format_{godot_format}"),
        "payload_size": len(data) - 52,
    }
    return info


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Godot 4 .ctex 1:1 Importer & TGA Benchmark Tool")
    subparsers = parser.add_subparsers(dest="command")

    # Encode command
    enc_parser = subparsers.add_parser("encode", help="Encode image to .ctex")
    enc_parser.add_argument("input", help="Path to input image (PNG, JPG, etc.)")
    enc_parser.add_argument("output", help="Path to output .ctex")
    enc_parser.add_argument("--mode", choices=["etc2", "s3tc", "dxt", "lossless", "lossy", "uncompressed"], default="etc2")
    enc_parser.add_argument("--mipmaps", action="store_true", default=True, help="Generate mipmaps chain")
    enc_parser.add_argument("--no-mipmaps", dest="mipmaps", action="store_false")
    enc_parser.add_argument("--quality", type=int, default=80, help="Lossy quality (1-100)")

    # TGA command
    tga_parser = subparsers.add_parser("to_tga", help="Convert image to uncompressed TGA")
    tga_parser.add_argument("input", help="Path to input image")
    tga_parser.add_argument("output", help="Path to output .tga")

    # Inspect command
    ins_parser = subparsers.add_parser("inspect", help="Inspect .ctex binary container")
    ins_parser.add_argument("file", help="Path to .ctex file")

    args = parser.parse_args()

    if args.command == "encode":
        res = encode_to_ctex(args.input, args.output, mode=args.mode, mipmaps=args.mipmaps, quality=args.quality)
        print(f"Encoded {args.input} -> {args.output}")
        print(f"  Format: {res['format_name']} (ID {res['format_id']})")
        print(f"  Dimensions: {res['orig_width']}x{res['orig_height']} (aligned: {res['stored_width']}x{res['stored_height']})")
        print(f"  Mipmaps: {res['mipmap_count']} levels")
        print(f"  Total file size: {res['file_size']:,} bytes (payload: {res['payload_size']:,} bytes)")
    elif args.command == "to_tga":
        res = save_to_tga(args.input, args.output)
        print(f"Saved {args.input} -> {args.output}")
        print(f"  Dimensions: {res['width']}x{res['height']} ({res['bpp']} bpp)")
        print(f"  File size: {res['file_size']:,} bytes")
        print(f"  Nominal GPU VRAM: {res['nominal_vram']:,} bytes ({res['nominal_vram_with_mips']:,} with mips)")
    elif args.command == "inspect":
        info = inspect_ctex(args.file)
        print(f"Inspecting {args.file}:")
        for k, v in info.items():
            print(f"  {k}: {v}")
    else:
        parser.print_help()
