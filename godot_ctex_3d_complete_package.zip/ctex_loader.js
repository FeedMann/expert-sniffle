/**
 * ctex_loader.js - Godot 4 .ctex & TGA Loader and Memory Profiler for JavaScript / Web / Node.js
 *
 * Implements 1:1 reading of:
 *   - Godot 4 CompressedTexture2D (.ctex) GST2 format
 *   - Truevision TGA uncompressed format
 *
 * Provides:
 *   - parseCTEX(arrayBuffer)
 *   - parseTGA(arrayBuffer)
 *   - calculateMemoryMetrics(tgaData, ctexData)
 *   - decodeToRGBA(parsedData)
 *   - uploadToWebGL(gl, parsedData)
 */

(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        define(['tex-decoder'], factory);
    } else if (typeof module === 'object' && module.exports) {
        module.exports = factory(require('tex-decoder'));
    } else {
        root.GodotTextureLoader = factory(root.TexDecoder);
    }
}(typeof self !== 'undefined' ? self : this, function (TexDecoder) {
    'use strict';

    // Godot 4 Constants
    const MAGIC = 'GST2';
    const FORMAT_VERSION = 1;

    const FORMAT_BIT_HAS_MIPMAPS = 1 << 23;
    const FORMAT_BIT_DETECT_3D = 1 << 24;
    const FORMAT_BIT_DETECT_NORMAL = 1 << 26;
    const FORMAT_BIT_DETECT_ROUGHNESS = 1 << 27;

    const DATA_FORMAT_IMAGE = 0;
    const DATA_FORMAT_PNG = 1;
    const DATA_FORMAT_WEBP = 2;
    const DATA_FORMAT_BASIS_UNIVERSAL = 3;

    const FORMAT_NAMES = {
        4: 'RGB8',
        5: 'RGBA8',
        17: 'DXT1 (BC1)',
        18: 'DXT3 (BC2)',
        19: 'DXT5 (BC3)',
        20: 'RGTC_R (BC4)',
        21: 'RGTC_RG (BC5)',
        22: 'BPTC_RGBA (BC7)',
        25: 'ETC1',
        30: 'ETC2_RGB8',
        31: 'ETC2_RGBA8',
        32: 'ETC2_RGB8A1',
        35: 'ASTC_4x4',
        37: 'ASTC_8x8'
    };

    // WebGL Compressed Format Enums
    const GL_COMPRESSED_RGB8_ETC2 = 0x9274;
    const GL_COMPRESSED_RGBA8_ETC2_EAC = 0x9278;
    const GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 0x83F0;
    const GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 0x83F3;

    /**
     * Parse Godot 4 .ctex file
     * @param {ArrayBuffer|Uint8Array} input
     */
    function parseCTEX(input) {
        const buffer = input.buffer ? input.buffer.slice(input.byteOffset, input.byteOffset + input.byteLength) : input;
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        if (bytes.length < 52) {
            throw new Error(`File too small for .ctex: ${bytes.length} bytes (minimum 52 bytes)`);
        }

        // Magic GST2
        const magic = String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]);
        if (magic !== MAGIC) {
            throw new Error(`Invalid Godot texture magic: '${magic}', expected 'GST2'`);
        }

        // GST2 Header (36 bytes)
        const version = view.getUint32(4, true);
        const origWidth = view.getUint32(8, true);
        const origHeight = view.getUint32(12, true);
        const flags = view.getUint32(16, true);
        const limitMipmap = view.getUint32(20, true);
        const reserved0 = view.getUint32(24, true);
        const reserved1 = view.getUint32(28, true);
        const reserved2 = view.getUint32(32, true);

        // Payload Header (16 bytes)
        const dataFormat = view.getUint32(36, true);
        const width = view.getUint16(40, true);
        const height = view.getUint16(42, true);
        const mipmapCount = view.getUint32(44, true);
        const formatId = view.getUint32(48, true);

        const hasMipmaps = (flags & FORMAT_BIT_HAS_MIPMAPS) !== 0;
        const formatName = FORMAT_NAMES[formatId] || `Unknown_${formatId}`;

        // Compute mipmap chain layout
        const mipLevels = [];
        let payloadOffset = 52;

        if (dataFormat === DATA_FORMAT_IMAGE) {
            // VRAM compressed (ETC2, DXT) or uncompressed raw
            const isETC2_RGB = (formatId === 30);
            const isETC2_RGBA = (formatId === 31);
            const isDXT1 = (formatId === 17);
            const isDXT5 = (formatId === 19);
            const isRGBA8 = (formatId === 5);
            const isRGB8 = (formatId === 4);

            const isBlockCompressed = isETC2_RGB || isETC2_RGBA || isDXT1 || isDXT5;
            const bytesPerBlock = (isETC2_RGB || isDXT1) ? 8 : (isETC2_RGBA || isDXT5) ? 16 : 0;

            let curW = width;
            let curH = height;
            const totalLevels = (hasMipmaps && mipmapCount > 0) ? (mipmapCount + 1) : 1;

            for (let i = 0; i < totalLevels; i++) {
                let levelBytes = 0;
                let padW = curW;
                let padH = curH;

                if (isBlockCompressed) {
                    padW = (curW + 3) & ~3;
                    padH = (curH + 3) & ~3;
                    const blocks = (padW * padH) / 16;
                    levelBytes = blocks * bytesPerBlock;
                } else if (isRGBA8) {
                    levelBytes = curW * curH * 4;
                } else if (isRGB8) {
                    levelBytes = curW * curH * 3;
                }

                const levelData = bytes.subarray(payloadOffset, payloadOffset + levelBytes);
                mipLevels.push({
                    level: i,
                    width: curW,
                    height: curH,
                    paddedWidth: padW,
                    paddedHeight: padH,
                    offset: payloadOffset,
                    byteLength: levelBytes,
                    data: levelData
                });

                payloadOffset += levelBytes;
                if (curW === 1 && curH === 1) break;
                curW = Math.max(1, curW >> 1);
                curH = Math.max(1, curH >> 1);
            }
        } else if (dataFormat === DATA_FORMAT_WEBP || dataFormat === DATA_FORMAT_PNG) {
            // Each mipmap level stored with uint32 size prefix
            const totalLevels = (hasMipmaps && mipmapCount > 0) ? (mipmapCount + 1) : 1;
            let curW = width;
            let curH = height;

            for (let i = 0; i < totalLevels; i++) {
                if (payloadOffset + 4 > bytes.length) break;
                const chunkSize = view.getUint32(payloadOffset, true);
                payloadOffset += 4;
                const chunkData = bytes.subarray(payloadOffset, payloadOffset + chunkSize);
                payloadOffset += chunkSize;

                mipLevels.push({
                    level: i,
                    width: curW,
                    height: curH,
                    paddedWidth: curW,
                    paddedHeight: curH,
                    byteLength: chunkSize,
                    data: chunkData
                });

                if (curW === 1 && curH === 1) break;
                curW = Math.max(1, curW >> 1);
                curH = Math.max(1, curH >> 1);
            }
        }

        // Calculate nominal GPU VRAM footprint
        let nominalVram = 0;
        if (formatId === 30) { // ETC2_RGB8
            nominalVram = mipLevels.reduce((sum, m) => sum + (m.paddedWidth * m.paddedHeight / 16) * 8, 0);
        } else if (formatId === 31) { // ETC2_RGBA8
            nominalVram = mipLevels.reduce((sum, m) => sum + (m.paddedWidth * m.paddedHeight / 16) * 16, 0);
        } else if (formatId === 17) { // DXT1
            nominalVram = mipLevels.reduce((sum, m) => sum + (m.paddedWidth * m.paddedHeight / 16) * 8, 0);
        } else if (formatId === 19) { // DXT5
            nominalVram = mipLevels.reduce((sum, m) => sum + (m.paddedWidth * m.paddedHeight / 16) * 16, 0);
        } else { // Uncompressed WebGL texture (RGBA8)
            nominalVram = mipLevels.reduce((sum, m) => sum + (m.width * m.height * 4), 0);
        }

        return {
            type: 'ctex',
            fileSize: bytes.length,
            headerSize: 52,
            payloadSize: bytes.length - 52,
            version: version,
            origWidth: origWidth,
            origHeight: origHeight,
            width: width,
            height: height,
            flags: flags,
            hasMipmaps: hasMipmaps,
            limitMipmap: limitMipmap,
            dataFormat: dataFormat,
            dataFormatName: ['IMAGE', 'PNG', 'WEBP', 'BASISU'][dataFormat] || 'UNKNOWN',
            formatId: formatId,
            formatName: formatName,
            mipmapCount: mipLevels.length > 0 ? (mipLevels.length - 1) : 0,
            mipLevels: mipLevels,
            nominalVram: nominalVram,
            rawBytes: bytes
        };
    }

    /**
     * Parse Truevision TGA file
     * @param {ArrayBuffer|Uint8Array} input
     */
    function parseTGA(input) {
        const buffer = input.buffer ? input.buffer.slice(input.byteOffset, input.byteOffset + input.byteLength) : input;
        const view = new DataView(buffer);
        const bytes = new Uint8Array(buffer);

        if (bytes.length < 18) {
            throw new Error(`File too small for TGA: ${bytes.length} bytes`);
        }

        const idLength = view.getUint8(0);
        const colorMapType = view.getUint8(1);
        const imageType = view.getUint8(2); // 2 = uncompressed truecolor, 10 = RLE truecolor
        const width = view.getUint16(12, true);
        const height = view.getUint16(14, true);
        const bpp = view.getUint8(16);
        const descriptor = view.getUint8(17);

        if (imageType !== 2 && imageType !== 10) {
            throw new Error(`Unsupported TGA image type: ${imageType} (only type 2 and 10 supported)`);
        }

        const isTopDown = (descriptor & 0x20) !== 0;
        const hasAlpha = (bpp === 32);
        const bytesPerPixel = bpp / 8;
        const pixelCount = width * height;

        let pixelOffset = 18 + idLength;
        const rgba = new Uint8Array(pixelCount * 4);

        if (imageType === 2) {
            // Uncompressed
            for (let y = 0; y < height; y++) {
                const targetY = isTopDown ? y : (height - 1 - y);
                for (let x = 0; x < width; x++) {
                    const srcIdx = pixelOffset + (y * width + x) * bytesPerPixel;
                    const dstIdx = (targetY * width + x) * 4;

                    const b = bytes[srcIdx];
                    const g = bytes[srcIdx + 1];
                    const r = bytes[srcIdx + 2];
                    const a = hasAlpha ? bytes[srcIdx + 3] : 255;

                    rgba[dstIdx] = r;
                    rgba[dstIdx + 1] = g;
                    rgba[dstIdx + 2] = b;
                    rgba[dstIdx + 3] = a;
                }
            }
        } else if (imageType === 10) {
            // RLE Compressed TGA
            let currentPixel = 0;
            let offset = pixelOffset;
            const tempPixels = new Uint8Array(pixelCount * 4);

            while (currentPixel < pixelCount && offset < bytes.length) {
                const packetHeader = bytes[offset++];
                const count = (packetHeader & 0x7F) + 1;
                const isRLE = (packetHeader & 0x80) !== 0;

                if (isRLE) {
                    const b = bytes[offset++];
                    const g = bytes[offset++];
                    const r = bytes[offset++];
                    const a = hasAlpha ? bytes[offset++] : 255;
                    for (let c = 0; c < count; c++) {
                        const idx = (currentPixel++) * 4;
                        tempPixels[idx] = r;
                        tempPixels[idx + 1] = g;
                        tempPixels[idx + 2] = b;
                        tempPixels[idx + 3] = a;
                    }
                } else {
                    for (let c = 0; c < count; c++) {
                        const b = bytes[offset++];
                        const g = bytes[offset++];
                        const r = bytes[offset++];
                        const a = hasAlpha ? bytes[offset++] : 255;
                        const idx = (currentPixel++) * 4;
                        tempPixels[idx] = r;
                        tempPixels[idx + 1] = g;
                        tempPixels[idx + 2] = b;
                        tempPixels[idx + 3] = a;
                    }
                }
            }

            // Orient top-down
            for (let y = 0; y < height; y++) {
                const targetY = isTopDown ? y : (height - 1 - y);
                for (let x = 0; x < width; x++) {
                    const srcIdx = (y * width + x) * 4;
                    const dstIdx = (targetY * width + x) * 4;
                    rgba[dstIdx] = tempPixels[srcIdx];
                    rgba[dstIdx + 1] = tempPixels[srcIdx + 1];
                    rgba[dstIdx + 2] = tempPixels[srcIdx + 2];
                    rgba[dstIdx + 3] = tempPixels[srcIdx + 3];
                }
            }
        }

        // Nominal VRAM calculation in WebGL (RGBA8 uncompressed):
        // Top level: width * height * 4
        // With mipmaps: + 33.3%
        const nominalVramNoMips = width * height * 4;
        const nominalVramWithMips = Math.round(nominalVramNoMips * 1.333333);

        return {
            type: 'tga',
            fileSize: bytes.length,
            width: width,
            height: height,
            bpp: bpp,
            hasAlpha: hasAlpha,
            isTopDown: isTopDown,
            rgbaData: rgba,
            nominalVram: nominalVramNoMips,
            nominalVramWithMips: nominalVramWithMips,
            rawBytes: bytes
        };
    }

    /**
     * Decompress CTEX payload to RGBA pixels for 2D Canvas or software fallback.
     * Uses tex-decoder when available.
     * @param {Object} ctex - Result of parseCTEX
     * @param {number} level - Mipmap level (default 0)
     * @returns {Uint8Array} RGBA pixels
     */
    function decodeCTEXtoRGBA(ctex, level = 0) {
        if (!ctex.mipLevels || !ctex.mipLevels[level]) {
            throw new Error(`Mipmap level ${level} not found in CTEX`);
        }

        const mip = ctex.mipLevels[level];

        if (ctex.dataFormat === DATA_FORMAT_IMAGE) {
            if (!TexDecoder) {
                throw new Error('tex-decoder is required to decode compressed textures on CPU.');
            }

            const formatId = ctex.formatId;
            let decoded = null;

            if (formatId === 30) { // ETC2_RGB8
                decoded = TexDecoder.decodeETC2RGB(mip.data, mip.paddedWidth, mip.paddedHeight);
                // Convert BGRA to RGBA
                decoded = TexDecoder.convertProfile(decoded, TexDecoder.COLOR_PROFILE.BGRA8, TexDecoder.COLOR_PROFILE.RGBA8);
            } else if (formatId === 31) { // ETC2_RGBA8
                decoded = TexDecoder.decodeETC2RGBA(mip.data, mip.paddedWidth, mip.paddedHeight);
                decoded = TexDecoder.convertProfile(decoded, TexDecoder.COLOR_PROFILE.BGRA8, TexDecoder.COLOR_PROFILE.RGBA8);
            } else if (formatId === 17) { // DXT1
                decoded = TexDecoder.decodeDXT1(mip.data, mip.paddedWidth, mip.paddedHeight);
            } else if (formatId === 19) { // DXT5
                decoded = TexDecoder.decodeDXT5(mip.data, mip.paddedWidth, mip.paddedHeight);
            } else if (formatId === 5) { // Uncompressed RGBA8
                return mip.data;
            } else {
                throw new Error(`Unsupported format for software decode: ${ctex.formatName} (ID ${formatId})`);
            }

            // Crop back to unpadded width & height if needed
            if (mip.paddedWidth !== mip.width || mip.paddedHeight !== mip.height) {
                const cropped = new Uint8Array(mip.width * mip.height * 4);
                for (let y = 0; y < mip.height; y++) {
                    const srcStart = (y * mip.paddedWidth) * 4;
                    const srcEnd = srcStart + (mip.width * 4);
                    const dstStart = (y * mip.width) * 4;
                    cropped.set(decoded.subarray(srcStart, srcEnd), dstStart);
                }
                return cropped;
            }

            return decoded;
        } else if (ctex.dataFormat === DATA_FORMAT_WEBP || ctex.dataFormat === DATA_FORMAT_PNG) {
            // In browser, create ImageBitmap or Blob from WebP/PNG chunk
            // In Node, return raw WebP/PNG buffer
            return mip.data;
        }

        throw new Error(`Unsupported data format: ${ctex.dataFormatName}`);
    }

    /**
     * Compute comparative memory metrics between TGA and Godot CTEX
     */
    function calculateMemoryMetrics(tga, ctex) {
        // Disk / Network Transfer comparison
        const transferTga = tga.fileSize;
        const transferCtex = ctex.fileSize;
        const transferSavedBytes = transferTga - transferCtex;
        const transferSavedPercent = ((transferSavedBytes / transferTga) * 100).toFixed(2);
        const transferRatio = (transferTga / transferCtex).toFixed(2);

        // CPU Decoding Memory Footprint (ArrayBuffers, decoded buffers, staging)
        // For TGA: uncompressed file buffer + decoded RGBA array = ~2x file size
        const cpuMemTga = tga.fileSize + (tga.width * tga.height * 4);
        // For CTEX VRAM compressed: file buffer + mip sliced view (0 decode buffer needed!)
        const cpuMemCtex = ctex.fileSize + ctex.payloadSize;
        const cpuSavedBytes = cpuMemTga - cpuMemCtex;
        const cpuSavedPercent = ((cpuSavedBytes / cpuMemTga) * 100).toFixed(2);

        // GPU VRAM Memory Footprint in WebGL:
        // TGA: Uploaded as gl.RGBA -> width * height * 4 (+ mipmaps if generated)
        const vramTgaNoMips = tga.width * tga.height * 4;
        const vramTgaWithMips = Math.round(vramTgaNoMips * 1.333333);
        const vramTga = ctex.hasMipmaps ? vramTgaWithMips : vramTgaNoMips;

        // CTEX: Uploaded as compressed texture (gl.compressedTexImage2D)
        const vramCtex = ctex.nominalVram;
        const vramSavedBytes = vramTga - vramCtex;
        const vramSavedPercent = ((vramSavedBytes / vramTga) * 100).toFixed(2);
        const vramRatio = (vramTga / vramCtex).toFixed(2);

        return {
            dimensions: `${tga.width}x${tga.height}`,
            hasMipmaps: ctex.hasMipmaps,
            ctexFormat: ctex.formatName,
            transfer: {
                tgaBytes: transferTga,
                ctexBytes: transferCtex,
                savedBytes: transferSavedBytes,
                savedPercent: parseFloat(transferSavedPercent),
                ratio: parseFloat(transferRatio)
            },
            cpuMemory: {
                tgaBytes: cpuMemTga,
                ctexBytes: cpuMemCtex,
                savedBytes: cpuSavedBytes,
                savedPercent: parseFloat(cpuSavedPercent)
            },
            gpuVram: {
                tgaBytes: vramTga,
                ctexBytes: vramCtex,
                savedBytes: vramSavedBytes,
                savedPercent: parseFloat(vramSavedPercent),
                ratio: parseFloat(vramRatio)
            }
        };
    }

    /**
     * Upload parsed texture into WebGL context
     * Supports both compressed upload (gl.compressedTexImage2D) and standard uncompressed upload.
     */
    function uploadToWebGL(gl, parsedTexture) {
        const texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, texture);

        if (parsedTexture.type === 'tga') {
            gl.texImage2D(
                gl.TEXTURE_2D,
                0,
                gl.RGBA,
                parsedTexture.width,
                parsedTexture.height,
                0,
                gl.RGBA,
                gl.UNSIGNED_BYTE,
                parsedTexture.rgbaData
            );
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            return {
                glTexture: texture,
                method: 'texImage2D (Uncompressed RGBA8)',
                vramBytes: parsedTexture.width * parsedTexture.height * 4,
                mipsUploaded: 1
            };
        }

        if (parsedTexture.type === 'ctex') {
            const extETC = gl.getExtension('WEBGL_compressed_texture_etc');
            const extS3TC = gl.getExtension('WEBGL_compressed_texture_s3tc');

            let internalFormat = null;
            if (parsedTexture.formatId === 30 && extETC) {
                internalFormat = extETC.COMPRESSED_RGB8_ETC2;
            } else if (parsedTexture.formatId === 31 && extETC) {
                internalFormat = extETC.COMPRESSED_RGBA8_ETC2_EAC;
            } else if (parsedTexture.formatId === 17 && extS3TC) {
                internalFormat = extS3TC.COMPRESSED_RGB_S3TC_DXT1_EXT;
            } else if (parsedTexture.formatId === 19 && extS3TC) {
                internalFormat = extS3TC.COMPRESSED_RGBA_S3TC_DXT5_EXT;
            }

            if (internalFormat) {
                // Direct hardware compressed upload!
                parsedTexture.mipLevels.forEach((mip, idx) => {
                    gl.compressedTexImage2D(
                        gl.TEXTURE_2D,
                        idx,
                        internalFormat,
                        mip.width,
                        mip.height,
                        0,
                        mip.data
                    );
                });

                const minFilter = parsedTexture.mipLevels.length > 1 ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR;
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

                return {
                    glTexture: texture,
                    method: 'compressedTexImage2D (Hardware VRAM Compressed)',
                    vramBytes: parsedTexture.nominalVram,
                    mipsUploaded: parsedTexture.mipLevels.length
                };
            } else {
                // Software fallback decode to RGBA
                const decodedRgba = decodeCTEXtoRGBA(parsedTexture, 0);
                gl.texImage2D(
                    gl.TEXTURE_2D,
                    0,
                    gl.RGBA,
                    parsedTexture.width,
                    parsedTexture.height,
                    0,
                    gl.RGBA,
                    gl.UNSIGNED_BYTE,
                    decodedRgba
                );
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

                return {
                    glTexture: texture,
                    method: 'texImage2D (Fallback Software Decoded)',
                    vramBytes: parsedTexture.width * parsedTexture.height * 4,
                    mipsUploaded: 1,
                    warning: 'Hardware extension not supported in this WebGL context; fell back to software decompression.'
                };
            }
        }
    }

    return {
        parseCTEX: parseCTEX,
        parseTGA: parseTGA,
        decodeCTEXtoRGBA: decodeCTEXtoRGBA,
        calculateMemoryMetrics: calculateMemoryMetrics,
        uploadToWebGL: uploadToWebGL,
        FORMAT_NAMES: FORMAT_NAMES
    };
}));
