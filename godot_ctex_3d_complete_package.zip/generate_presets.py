#!/usr/bin/env python3
import os
import math
from PIL import Image, ImageDraw
import numpy as np

os.makedirs("presets", exist_ok=True)

# 1. Game UI with Alpha (512x512)
img_ui = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
draw = ImageDraw.Draw(img_ui)

draw.rounded_rectangle([32, 32, 480, 480], radius=24, fill=(28, 32, 48, 235), outline=(100, 140, 240, 255), width=4)
draw.rounded_rectangle([48, 48, 464, 110], radius=12, fill=(40, 50, 80, 240), outline=(130, 180, 255, 200), width=2)
draw.text((70, 68), "INVENTORY / EQUIPMENT", fill=(255, 255, 255, 255))

for row in range(3):
    for col in range(4):
        x = 64 + col * 98
        y = 135 + row * 98
        draw.rounded_rectangle([x, y, x + 82, y + 82], radius=10, fill=(18, 22, 34, 210), outline=(70, 90, 130, 200), width=2)
        draw.ellipse([x + 18, y + 18, x + 64, y + 64], fill=((row * 60 + col * 40) % 255, 140, 220, 180))

draw.rounded_rectangle([64, 440, 240, 462], radius=6, fill=(180, 40, 40, 230), outline=(255, 100, 100, 255), width=2)
draw.rounded_rectangle([272, 440, 448, 462], radius=6, fill=(40, 90, 220, 230), outline=(100, 180, 255, 255), width=2)

img_ui.save("presets/game_ui.png")

# 2. Detailed Opaque Artwork / Gradient (512x512)
img_art = Image.new("RGB", (512, 512), (10, 15, 28))
draw_art = ImageDraw.Draw(img_art)

for y in range(512):
    t = y / 512.0
    r = int(20 + 200 * t)
    g = int(30 + 120 * math.sin(t * math.pi))
    b = int(240 - 180 * t)
    draw_art.line([(0, y), (512, y)], fill=(r, g, b))

for i in range(12):
    cx = 256 + int(160 * math.cos(i * math.pi / 6))
    cy = 256 + int(160 * math.sin(i * math.pi / 6))
    rad = 40 + i * 4
    draw_art.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], outline=(255, 220, 120), width=3)

img_art.save("presets/gradient_art.png")

# 3. Tangent-Space Normal Map (512x512)
norm_arr = np.zeros((512, 512, 3), dtype=np.uint8)
norm_arr[:, :, 0] = 128
norm_arr[:, :, 1] = 128
norm_arr[:, :, 2] = 255

y_grid, x_grid = np.mgrid[:512, :512]
for bx, by, br in [(160, 160, 100), (360, 160, 80), (256, 360, 120)]:
    dist_sq = (x_grid - bx)**2 + (y_grid - by)**2
    mask = dist_sq < (br**2)
    nz = np.sqrt(np.maximum(0.0, br**2 - dist_sq[mask])) / br
    nx = (x_grid[mask] - bx) / br
    ny = (y_grid[mask] - by) / br

    norm_arr[mask, 0] = np.clip((nx * 0.5 + 0.5) * 255, 0, 255).astype(np.uint8)
    norm_arr[mask, 1] = np.clip((ny * 0.5 + 0.5) * 255, 0, 255).astype(np.uint8)
    norm_arr[mask, 2] = np.clip((nz * 0.5 + 0.5) * 255, 0, 255).astype(np.uint8)

img_norm = Image.fromarray(norm_arr, "RGB")
img_norm.save("presets/normal_map.png")

print("Generated sample presets successfully in presets/")
