/**
 * custom_engine_example.cpp
 * 
 * Demonstrates:
 *   1. Loading .ctex files in C++
 *   2. Deduplication & Resource Caching (same texture -> same pointer -> same draw call)
 *   3. Texture Array & Atlas batching concept for 3D multi-mesh rendering
 */

#include "custom_engine_example.h"
#include <iostream>

using namespace CustomEngine;

int main() {
    std::cout << "==========================================================" << std::endl;
    std::cout << " CUSTOM ENGINE TEXTURE PIPELINE & CACHING DEMONSTRATION" << std::endl;
    std::cout << "==========================================================" << std::endl;

    auto& cache = TextureCache::get_singleton();

    // 1. Load texture
    std::cout << "\n[Step 1] Loading 'presets/game_ui_etc2.ctex' for Cube #1..." << std::endl;
    auto tex1 = cache.load("presets/game_ui_etc2.ctex");
    if (tex1) {
        std::cout << "  -> Loaded: " << tex1->orig_width << "x" << tex1->orig_height
                  << " (" << tex1->mip_levels.size() << " pre-baked mips)" << std::endl;
        std::cout << "  -> Nominal GPU VRAM: " << tex1->get_nominal_vram() << " bytes" << std::endl;
    }

    // 2. Load SAME texture for Cube #2 through Cube #100
    std::cout << "\n[Step 2] Loading 'presets/game_ui_etc2.ctex' for Cube #2..." << std::endl;
    auto tex2 = cache.load("presets/game_ui_etc2.ctex");

    // 3. Verify Pointer Equality (Zero Redundant GPU Allocations!)
    if (tex1.get() == tex2.get()) {
        std::cout << "  [SUCCESS] Cache Hit! Both cubes point to identical memory (" << tex1.get() << ")" << std::endl;
        std::cout << "  -> Only 1 GPU Texture allocated. VRAM cost for 100 cubes = " << tex1->get_nominal_vram() << " bytes (NOT " << tex1->get_nominal_vram() * 100 << " bytes!)" << std::endl;
    }

    // 4. Batching Explanation
    std::cout << "\n==========================================================" << std::endl;
    std::cout << " HOW TO ACHIEVE THE SAME DRAW CALL ('SAME CALL') IN 3D:" << std::endl;
    std::cout << "==========================================================" << std::endl;
    std::cout << "1. INSTANCING / MULTIMESH:" << std::endl;
    std::cout << "   If meshes share the same material/texture pointer (tex1 == tex2)," << std::endl;
    std::cout << "   a single 'glDrawElementsInstanced()' draws thousands of moving cubes" << std::endl;
    std::cout << "   with ZERO texture rebinds in 1 SINGLE DRAW CALL!" << std::endl;
    std::cout << "\n2. TEXTURE ARRAYS (Texture2DArray):" << std::endl;
    std::cout << "   Pack multiple 512x512 textures as layers in one 2D Array Texture." << std::endl;
    std::cout << "   The vertex attribute supplies layer index. 1 draw call draws" << std::endl;
    std::cout << "   cubes with completely different textures!" << std::endl;
    std::cout << "\n3. BINDLESS TEXTURES / DESCRIPTOR INDEXING:" << std::endl;
    std::cout << "   In Vulkan / WebGPU / Modern GL, all textures are bound once in a global" << std::endl;
    std::cout << "   descriptor array. The shader indexes texture by uint32 material ID." << std::endl;
    std::cout << "==========================================================" << std::endl;

    return 0;
}
