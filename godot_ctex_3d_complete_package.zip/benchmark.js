#!/usr/bin/env node
/**
 * benchmark.js - Benchmark & Memory Analysis: TGA vs Godot 4 .ctex
 *
 * Runs loading and memory profiling for:
 *   1. Uncompressed Truevision TGA (baseline)
 *   2. Godot 4 CTEX (Mobile/Web ETC2)
 *   3. Godot 4 CTEX (Desktop/Web DXT/S3TC)
 *   4. Godot 4 CTEX (Lossless WebP)
 *   5. Godot 4 CTEX (Lossy WebP)
 */

const fs = require('fs');
const path = require('path');
const loader = require('./ctex_loader.js');

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

function runBenchmarkOnPair(imageTitle, tgaPath, ctexVariants) {
    console.log('='.repeat(80));
    console.log(`TEST SUITE: ${imageTitle}`);
    console.log('='.repeat(80));

    if (!fs.existsSync(tgaPath)) {
        console.error(`TGA file not found: ${tgaPath}`);
        return;
    }

    const tgaBuffer = fs.readFileSync(tgaPath);
    const tgaStart = process.hrtime.bigint();
    const tga = loader.parseTGA(tgaBuffer);
    const tgaEnd = process.hrtime.bigint();
    const tgaParseTimeMs = Number(tgaEnd - tgaStart) / 1e6;

    console.log(`Baseline TGA (${tga.width}x${tga.height}, ${tga.bpp} bpp):`);
    console.log(`  File Size on Disk/Transfer:  ${formatBytes(tga.fileSize)} (${tga.fileSize.toLocaleString()} bytes)`);
    console.log(`  Parse / Swizzle Time:        ${tgaParseTimeMs.toFixed(3)} ms`);
    console.log(`  CPU Memory (Buffer + RGBA):  ${formatBytes(tga.fileSize + tga.rgbaData.length)}`);
    console.log(`  GPU VRAM (Nominal RGBA8):    ${formatBytes(tga.nominalVram)} (without mips)`);
    console.log(`  GPU VRAM (With Mipmaps):     ${formatBytes(tga.nominalVramWithMips)}`);
    console.log('-'.repeat(80));

    const rows = [];

    for (const variant of ctexVariants) {
        if (!fs.existsSync(variant.path)) continue;

        const ctexBuffer = fs.readFileSync(variant.path);
        const cStart = process.hrtime.bigint();
        const ctex = loader.parseCTEX(ctexBuffer);
        const cEnd = process.hrtime.bigint();
        const ctexParseTimeMs = Number(cEnd - cStart) / 1e6;

        const metrics = loader.calculateMemoryMetrics(tga, ctex);

        rows.push({
            format: variant.name,
            fileSize: ctex.fileSize,
            fileSavedPct: metrics.transfer.savedPercent,
            fileRatio: metrics.transfer.ratio,
            cpuMem: metrics.cpuMemory.ctexBytes,
            gpuVram: metrics.gpuVram.ctexBytes,
            vramSavedPct: metrics.gpuVram.savedPercent,
            vramRatio: metrics.gpuVram.ratio,
            parseTimeMs: ctexParseTimeMs,
            mips: ctex.mipmapCount
        });
    }

    // Print table
    console.log(
        'Format'.padEnd(20) +
        'File Size'.padEnd(14) +
        'Disk Saved'.padEnd(14) +
        'GPU VRAM'.padEnd(14) +
        'VRAM Saved'.padEnd(14) +
        'Ratio'.padEnd(8) +
        'Parse (ms)'
    );
    console.log('-'.repeat(80));

    // Baseline row
    console.log(
        'TGA (Baseline)'.padEnd(20) +
        formatBytes(tga.fileSize).padEnd(14) +
        '0.00%'.padEnd(14) +
        formatBytes(tga.nominalVramWithMips).padEnd(14) +
        '0.00%'.padEnd(14) +
        '1.0x'.padEnd(8) +
        tgaParseTimeMs.toFixed(3)
    );

    for (const r of rows) {
        console.log(
            r.format.padEnd(20) +
            formatBytes(r.fileSize).padEnd(14) +
            (r.fileSavedPct >= 0 ? `-${r.fileSavedPct}%` : `+${-r.fileSavedPct}%`).padEnd(14) +
            formatBytes(r.gpuVram).padEnd(14) +
            (r.vramSavedPct >= 0 ? `-${r.vramSavedPct}%` : `+${-r.vramSavedPct}%`).padEnd(14) +
            `${r.vramRatio}x`.padEnd(8) +
            r.parseTimeMs.toFixed(3)
        );
    }
    console.log('='.repeat(80));
    console.log();
}

function main() {
    console.log('\n================================================================================');
    console.log(' GODOT 4 CTEX vs TGA: MEMORY SAVINGS BENCHMARK');
    console.log('================================================================================\n');

    // Suite 1: RGBA Texture with Alpha
    runBenchmarkOnPair('Game UI / Sprite with Alpha (512x512 RGBA)', 'test_sample.tga', [
        { name: 'CTEX ETC2_RGBA8', path: 'test_sample_etc2.ctex' },
        { name: 'CTEX DXT5 (BC3)', path: 'test_sample_dxt.ctex' },
        { name: 'CTEX Lossless WebP', path: 'test_sample_lossless.ctex' },
        { name: 'CTEX Lossy WebP', path: 'test_sample_lossy.ctex' },
        { name: 'CTEX Raw RGBA8', path: 'test_sample_raw.ctex' }
    ]);

    // Suite 2: Opaque RGB Texture
    runBenchmarkOnPair('Detailed Gradient / Opaque Texture (512x512 RGB)', 'test_rgb.tga', [
        { name: 'CTEX ETC2_RGB8', path: 'test_rgb_etc2.ctex' }
    ]);
}

if (require.main === module) {
    main();
}
