/**
 * app.js - Frontend controller for Godot 4 CTEX vs TGA 3D showcase & WebGL profiler
 */

document.addEventListener('DOMContentLoaded', async () => {
    // Nav & View Switching
    const btnView3D = document.getElementById('btn-view-3d');
    const btnView2D = document.getElementById('btn-view-2d');
    const section3D = document.getElementById('section-3d-showcase');
    const section2D = document.getElementById('section-2d-inspector');

    btnView3D.addEventListener('click', () => {
        btnView3D.classList.add('active');
        btnView2D.classList.remove('active');
        section3D.style.display = 'block';
        section2D.style.display = 'none';
        onWindowResize();
    });

    btnView2D.addEventListener('click', () => {
        btnView2D.classList.add('active');
        btnView3D.classList.remove('active');
        section2D.style.display = 'block';
        section3D.style.display = 'none';
    });

    // Controls
    const presetSelect = document.getElementById('preset-select');
    const formatSelect = document.getElementById('format-select');
    const cubeCountSlider = document.getElementById('cube-count-slider');
    const cubeCountLabel = document.getElementById('cube-count-label');
    const patternSelect = document.getElementById('pattern-select');

    // 2D Inspector Elements
    const mipmapSlider = document.getElementById('mipmap-slider');
    const mipLabel = document.getElementById('mip-label');
    const canvasTga = document.getElementById('canvas-tga');
    const canvasCtex = document.getElementById('canvas-ctex');

    // 3D Canvas Elements
    const canvas3DTga = document.getElementById('canvas-3d-tga');
    const canvas3DCtex = document.getElementById('canvas-3d-ctex');

    // Metrics & Overlays
    const vramSavedPct = document.getElementById('vram-saved-pct');
    const vramNumbers = document.getElementById('vram-numbers');
    const vramRatioBadge = document.getElementById('vram-ratio-badge');
    const vramBarSaved = document.getElementById('vram-bar-saved');
    const vramBarCtex = document.getElementById('vram-bar-ctex');
    const cacheBandwidthStat = document.getElementById('cache-bandwidth-stat');

    const overlayTgaStat = document.getElementById('overlay-tga-stat');
    const overlayCtexStat = document.getElementById('overlay-ctex-stat');
    const tgaPerMat = document.getElementById('tga-per-mat');
    const ctexPerMat = document.getElementById('ctex-per-mat');

    const tgaDim = document.getElementById('tga-dim');
    const tgaFilesize = document.getElementById('tga-filesize');
    const tgaVram = document.getElementById('tga-vram');
    const tgaFormatBadge = document.getElementById('tga-format-badge');

    const ctexFormatBadge = document.getElementById('ctex-format-badge');
    const ctexFilesize = document.getElementById('ctex-filesize');
    const ctexVram = document.getElementById('ctex-vram');

    const headerTableBody = document.getElementById('header-table-body');
    const mipsTableBody = document.getElementById('mips-table-body');
    const extTableBody = document.getElementById('ext-table-body');

    // Modal
    const btnOpenUpload = document.getElementById('btn-open-upload');
    const uploadModal = document.getElementById('upload-modal');
    const modalBtnCancel = document.getElementById('modal-btn-cancel');
    const modalBtnSubmit = document.getElementById('modal-btn-submit');
    const modalFileInput = document.getElementById('modal-file-input');
    const modalFormatSelect = document.getElementById('modal-format-select');
    const modalMipsSelect = document.getElementById('modal-mips-select');

    // Tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    let presetsData = [];
    let currentPreset = null;
    let currentTga = null;
    let currentCtex = null;
    let cubeCount = 16;
    let currentPattern = 'tunnel';

    function formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
    }

    // Diagnostics
    function checkWebGLSupport() {
        const testCanvas = document.createElement('canvas');
        const gl = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl');
        if (!gl) {
            document.getElementById('gpu-badge').textContent = 'Canvas 2D Mode';
            return { supported: false };
        }

        const extETC = gl.getExtension('WEBGL_compressed_texture_etc');
        const extS3TC = gl.getExtension('WEBGL_compressed_texture_s3tc');
        const extASTC = gl.getExtension('WEBGL_compressed_texture_astc');

        const extensions = [
            { name: 'WEBGL_compressed_texture_etc (ETC2)', status: !!extETC, note: 'Godot Mobile/Web Standard' },
            { name: 'WEBGL_compressed_texture_s3tc (DXT/BCn)', status: !!extS3TC, note: 'Godot Desktop Web Standard' },
            { name: 'WEBGL_compressed_texture_astc (ASTC)', status: !!extASTC, note: 'High Quality Mobile Variant' }
        ];

        extTableBody.innerHTML = extensions.map(e => `
            <tr>
                <td><code>${e.name}</code><br><small style="color: var(--text-muted);">${e.note}</small></td>
                <td>
                    <span class="tag-badge" style="${e.status ? 'color: #55d61f; border-color: rgba(56, 176, 0, 0.4); background: rgba(56, 176, 0, 0.1);' : 'color: #8d99ae;'}">
                        ${e.status ? 'Supported (Hardware Accelerated)' : 'Not Supported (CPU Software Fallback)'}
                    </span>
                </td>
            </tr>
        `).join('');

        return {
            supported: true,
            extETC: !!extETC,
            extS3TC: !!extS3TC,
            extASTC: !!extASTC
        };
    }

    const gpuInfo = checkWebGLSupport();

    // ==========================================
    // THREE.JS 3D SCENE SETUP
    // ==========================================
    let sceneTga, sceneCtex;
    let cameraTga, cameraCtex;
    let rendererTga, rendererCtex;
    let cubesTga = [], cubesCtex = [];
    let materialTga = null, materialCtex = null;
    let threeTexTga = null, threeTexCtex = null;

    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };
    let cameraAngle = { theta: 0, phi: 0.2, radius: 14 };

    function initThreeScenes() {
        const width = canvas3DTga.clientWidth || 600;
        const height = canvas3DTga.clientHeight || 420;

        // Renderer TGA
        rendererTga = new THREE.WebGLRenderer({ canvas: canvas3DTga, antialias: true, alpha: true });
        rendererTga.setSize(width, height, false);
        rendererTga.setPixelRatio(window.devicePixelRatio || 1);

        // Renderer CTEX
        rendererCtex = new THREE.WebGLRenderer({ canvas: canvas3DCtex, antialias: true, alpha: true });
        rendererCtex.setSize(width, height, false);
        rendererCtex.setPixelRatio(window.devicePixelRatio || 1);

        // Scenes
        sceneTga = new THREE.Scene();
        sceneCtex = new THREE.Scene();

        // Cameras
        cameraTga = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
        cameraCtex = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);

        // Lighting
        [sceneTga, sceneCtex].forEach(scene => {
            const ambient = new THREE.AmbientLight(0xffffff, 0.85);
            scene.add(ambient);

            const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
            dirLight.position.set(5, 10, 7);
            scene.add(dirLight);

            const backLight = new THREE.DirectionalLight(0x478cbf, 0.6);
            backLight.position.set(-5, -5, -5);
            scene.add(backLight);
        });

        updateCameraPosition();
        setupMouseControls();
    }

    function updateCameraPosition() {
        const x = cameraAngle.radius * Math.sin(cameraAngle.theta) * Math.cos(cameraAngle.phi);
        const y = cameraAngle.radius * Math.sin(cameraAngle.phi);
        const z = cameraAngle.radius * Math.cos(cameraAngle.theta) * Math.cos(cameraAngle.phi);

        cameraTga.position.set(x, y, z);
        cameraTga.lookAt(0, 0, currentPattern === 'tunnel' ? -15 : 0);

        cameraCtex.position.set(x, y, z);
        cameraCtex.lookAt(0, 0, currentPattern === 'tunnel' ? -15 : 0);
    }

    function setupMouseControls() {
        const canvases = [canvas3DTga, canvas3DCtex];

        canvases.forEach(canvas => {
            canvas.addEventListener('mousedown', (e) => {
                isDragging = true;
                previousMousePosition = { x: e.clientX, y: e.clientY };
            });

            canvas.addEventListener('wheel', (e) => {
                e.preventDefault();
                cameraAngle.radius = Math.max(4, Math.min(40, cameraAngle.radius + e.deltaY * 0.03));
                updateCameraPosition();
            }, { passive: false });
        });

        window.addEventListener('mouseup', () => { isDragging = false; });
        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const deltaX = e.clientX - previousMousePosition.x;
            const deltaY = e.clientY - previousMousePosition.y;

            cameraAngle.theta -= deltaX * 0.008;
            cameraAngle.phi = Math.max(-Math.PI / 2.5, Math.min(Math.PI / 2.5, cameraAngle.phi + deltaY * 0.008));

            updateCameraPosition();
            previousMousePosition = { x: e.clientX, y: e.clientY };
        });
    }

    function onWindowResize() {
        const width = canvas3DTga.clientWidth;
        const height = canvas3DTga.clientHeight;
        if (!width || !height) return;

        rendererTga.setSize(width, height, false);
        rendererCtex.setSize(width, height, false);

        cameraTga.aspect = width / height;
        cameraTga.updateProjectionMatrix();

        cameraCtex.aspect = width / height;
        cameraCtex.updateProjectionMatrix();
    }

    window.addEventListener('resize', onWindowResize);

    // Build 3D Cubes
    function buildCubes() {
        // Clear existing
        cubesTga.forEach(c => sceneTga.remove(c));
        cubesCtex.forEach(c => sceneCtex.remove(c));
        cubesTga = [];
        cubesCtex = [];

        const geometry = new THREE.BoxGeometry(1.6, 1.6, 1.6);

        for (let i = 0; i < cubeCount; i++) {
            const cubeT = new THREE.Mesh(geometry, materialTga || new THREE.MeshStandardMaterial({ color: 0x888888 }));
            const cubeC = new THREE.Mesh(geometry, materialCtex || new THREE.MeshStandardMaterial({ color: 0x888888 }));

            sceneTga.add(cubeT);
            sceneCtex.add(cubeC);

            cubesTga.push(cubeT);
            cubesCtex.push(cubeC);
        }
    }

    // Build Three.js Texture from parsed TGA
    function createThreeTextureFromTGA(tga) {
        const tex = new THREE.DataTexture(
            tga.rgbaData,
            tga.width,
            tga.height,
            THREE.RGBAFormat,
            THREE.UnsignedByteType
        );
        tex.minFilter = THREE.LinearMipmapLinearFilter;
        tex.magFilter = THREE.LinearFilter;
        tex.generateMipmaps = true; // Simulates GPU on-the-fly gl.generateMipmap()
        tex.needsUpdate = true;
        return tex;
    }

    // Build Three.js Texture from parsed CTEX (using pre-baked offline mip chain!)
    function createThreeTextureFromCTEX(ctex) {
        if (ctex.dataFormat === 0) { // DATA_FORMAT_IMAGE
            const isETC2_RGBA = (ctex.formatId === 31);
            const isETC2_RGB = (ctex.formatId === 30);
            const isDXT1 = (ctex.formatId === 17);
            const isDXT5 = (ctex.formatId === 19);

            const hasHardwareSupport = (
                ((isETC2_RGBA || isETC2_RGB) && gpuInfo.extETC) ||
                ((isDXT1 || isDXT5) && gpuInfo.extS3TC)
            );

            if (hasHardwareSupport) {
                let threeFormat = THREE.RGBA_ETC2_EAC_Format;
                if (isETC2_RGB) threeFormat = THREE.RGB_ETC2_Format;
                else if (isDXT1) threeFormat = THREE.RGB_S3TC_DXT1_Format;
                else if (isDXT5) threeFormat = THREE.RGBA_S3TC_DXT5_Format;

                const mipmaps = ctex.mipLevels.map(m => ({
                    data: m.data,
                    width: m.width,
                    height: m.height
                }));

                const compTex = new THREE.CompressedTexture(
                    mipmaps,
                    ctex.width,
                    ctex.height,
                    threeFormat,
                    THREE.UnsignedByteType
                );
                compTex.minFilter = THREE.LinearMipmapLinearFilter;
                compTex.magFilter = THREE.LinearFilter;
                compTex.generateMipmaps = false; // Zero downsampling at runtime: pre-baked in file!
                compTex.needsUpdate = true;
                return compTex;
            } else {
                // Software decoded fallback with pre-baked mip levels
                const mipmaps = ctex.mipLevels.map((m, idx) => {
                    const rgba = GodotTextureLoader.decodeCTEXtoRGBA(ctex, idx);
                    return {
                        data: rgba,
                        width: m.width,
                        height: m.height
                    };
                });

                const dataTex = new THREE.DataTexture(
                    mipmaps[0].data,
                    ctex.width,
                    ctex.height,
                    THREE.RGBAFormat,
                    THREE.UnsignedByteType
                );
                dataTex.mipmaps = mipmaps;
                dataTex.minFilter = THREE.LinearMipmapLinearFilter;
                dataTex.magFilter = THREE.LinearFilter;
                dataTex.generateMipmaps = false;
                dataTex.needsUpdate = true;
                return dataTex;
            }
        } else {
            // WebP/PNG
            const decoded = GodotTextureLoader.decodeCTEXtoRGBA(ctex, 0);
            const dataTex = new THREE.DataTexture(decoded, ctex.width, ctex.height, THREE.RGBAFormat);
            dataTex.minFilter = THREE.LinearMipmapLinearFilter;
            dataTex.magFilter = THREE.LinearFilter;
            dataTex.generateMipmaps = true;
            dataTex.needsUpdate = true;
            return dataTex;
        }
    }

    // Update Materials on all cubes
    function update3DMaterials() {
        if (!currentTga || !currentCtex) return;

        if (threeTexTga) threeTexTga.dispose();
        if (threeTexCtex) threeTexCtex.dispose();

        threeTexTga = createThreeTextureFromTGA(currentTga);
        threeTexCtex = createThreeTextureFromCTEX(currentCtex);

        materialTga = new THREE.MeshStandardMaterial({
            map: threeTexTga,
            roughness: 0.35,
            metalness: 0.15
        });

        materialCtex = new THREE.MeshStandardMaterial({
            map: threeTexCtex,
            roughness: 0.35,
            metalness: 0.15
        });

        cubesTga.forEach(c => c.material = materialTga);
        cubesCtex.forEach(c => c.material = materialCtex);

        // Update 3D VRAM HUD
        const vramPerTga = currentTga.nominalVramWithMips;
        const vramPerCtex = currentCtex.nominalVram;
        const totalVramTga = vramPerTga * cubeCount;
        const totalVramCtex = vramPerCtex * cubeCount;
        const totalSavedBytes = totalVramTga - totalVramCtex;
        const totalSavedPct = ((totalSavedBytes / totalVramTga) * 100).toFixed(1);
        const ratio = (totalVramTga / totalVramCtex).toFixed(1);

        vramSavedPct.textContent = `${totalSavedPct}% Saved`;
        vramNumbers.textContent = `TGA: ${formatBytes(totalVramTga)} \u2192 CTEX: ${formatBytes(totalVramCtex)} (${formatBytes(totalSavedBytes)} Saved)`;
        vramRatioBadge.textContent = `${ratio}x Less VRAM`;

        const ctexPct = Math.min(100, Math.max(5, (totalVramCtex / totalVramTga) * 100));
        vramBarCtex.style.width = `${ctexPct}%`;
        vramBarSaved.style.width = `${100 - ctexPct}%`;

        tgaPerMat.textContent = `${formatBytes(vramPerTga)} (with mips)`;
        ctexPerMat.textContent = `${formatBytes(vramPerCtex)} (-${totalSavedPct}%)`;

        overlayTgaStat.textContent = `VRAM: ${formatBytes(totalVramTga)} | 32 bpp`;
        overlayCtexStat.textContent = `VRAM: ${formatBytes(totalVramCtex)} | ${currentCtex.formatId === 30 ? '4 bpp' : '8 bpp'}`;

        cacheBandwidthStat.textContent = currentCtex.formatId === 30 ? '4 bits/texel (8:1)' : '8 bits/texel (4:1)';
    }

    // Animation Loop
    let clock = new THREE.Clock();
    function animate() {
        requestAnimationFrame(animate);
        const elapsed = clock.getElapsedTime();

        for (let i = 0; i < cubeCount; i++) {
            const cubeT = cubesTga[i];
            const cubeC = cubesCtex[i];
            if (!cubeT || !cubeC) continue;

            let x = 0, y = 0, z = 0;

            if (currentPattern === 'tunnel') {
                // Perspective Depth Tunnel
                const depthStep = 2.8;
                const totalDepth = cubeCount * depthStep;
                const offsetZ = (elapsed * 4.5 + i * depthStep) % totalDepth;
                z = -offsetZ;
                const angle = i * 0.7 + elapsed * 0.4;
                const radius = 2.8 + Math.sin(i * 0.4 + elapsed) * 0.8;
                x = Math.cos(angle) * radius;
                y = Math.sin(angle) * radius;

                cubeT.rotation.x = elapsed * 0.8 + i;
                cubeT.rotation.y = elapsed * 1.1 + i;
                cubeC.rotation.x = elapsed * 0.8 + i;
                cubeC.rotation.y = elapsed * 1.1 + i;
            } else if (currentPattern === 'orbit') {
                // Orbiting Grid
                const ring = Math.floor(i / 8);
                const posInRing = i % 8;
                const radius = 3.5 + ring * 3.0;
                const angle = (posInRing / 8) * Math.PI * 2 + elapsed * (0.4 / (ring + 1));
                x = Math.cos(angle) * radius;
                z = Math.sin(angle) * radius;
                y = Math.sin(elapsed * 2 + i) * 1.2;

                cubeT.rotation.x = elapsed + i * 0.2;
                cubeT.rotation.y = elapsed * 1.2 + i * 0.3;
                cubeC.rotation.x = elapsed + i * 0.2;
                cubeC.rotation.y = elapsed * 1.2 + i * 0.3;
            } else if (currentPattern === 'spiral') {
                // DNA Helix Wave
                const t = (i / cubeCount) * Math.PI * 4 + elapsed * 1.5;
                const strand = i % 2 === 0 ? 1 : -1;
                x = Math.cos(t) * 3.5 * strand;
                y = Math.sin(t) * 3.5;
                z = ((i / cubeCount) - 0.5) * 22;

                cubeT.rotation.x = t;
                cubeT.rotation.y = t * 0.5;
                cubeC.rotation.x = t;
                cubeC.rotation.y = t * 0.5;
            }

            cubeT.position.set(x, y, z);
            cubeC.position.set(x, y, z);
        }

        rendererTga.render(sceneTga, cameraTga);
        rendererCtex.render(sceneCtex, cameraCtex);
    }

    // Pattern & Cube Count Event Handlers
    patternSelect.addEventListener('change', (e) => {
        currentPattern = e.target.value;
        if (currentPattern === 'tunnel') {
            cameraAngle.theta = 0;
            cameraAngle.phi = 0.05;
            cameraAngle.radius = 10;
        } else {
            cameraAngle.theta = 0.6;
            cameraAngle.phi = 0.3;
            cameraAngle.radius = 16;
        }
        updateCameraPosition();
    });

    cubeCountSlider.addEventListener('input', (e) => {
        cubeCount = parseInt(e.target.value, 10);
        cubeCountLabel.textContent = cubeCount;
        buildCubes();
        update3DMaterials();
    });

    // 2D Canvas Helpers
    function renderRgbaToCanvas(canvas, rgbaBytes, width, height) {
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        const imgData = ctx.createImageData(width, height);
        imgData.data.set(rgbaBytes);
        ctx.putImageData(imgData, 0, 0);
    }

    function updateHeaderInspector(ctex) {
        const rows = [
            { offset: '0x00 - 0x03', field: 'Magic Identifier', type: 'char[4]', val: 'GST2', desc: 'Godot Streamable Texture 2D signature' },
            { offset: '0x04 - 0x07', field: 'Format Version', type: 'uint32', val: ctex.version, desc: 'Current engine format version (1)' },
            { offset: '0x08 - 0x0B', field: 'Original Width', type: 'uint32', val: `${ctex.origWidth} px`, desc: 'Unpadded source texture width' },
            { offset: '0x0C - 0x0F', field: 'Original Height', type: 'uint32', val: `${ctex.origHeight} px`, desc: 'Unpadded source texture height' },
            { offset: '0x10 - 0x13', field: 'Flags Bitmask', type: 'uint32', val: `0x${ctex.flags.toString(16).padStart(8, '0')}`, desc: `FORMAT_BIT_HAS_MIPMAPS = ${ctex.hasMipmaps}` },
            { offset: '0x14 - 0x17', field: 'Mipmap Limit', type: 'uint32', val: ctex.limitMipmap, desc: 'Max mipmap reduction limit' },
            { offset: '0x18 - 0x23', field: 'Reserved[3]', type: 'uint32[3]', val: '0, 0, 0', desc: 'Reserved for future engine flags' },
            { offset: '0x24 - 0x27', field: 'Payload Data Format', type: 'uint32', val: `${ctex.dataFormat} (${ctex.dataFormatName})`, desc: '0=IMAGE, 1=PNG, 2=WEBP, 3=BASISU' },
            { offset: '0x28 - 0x29', field: 'Aligned Width', type: 'uint16', val: `${ctex.width} px`, desc: 'Padded to 4x4 block multiple' },
            { offset: '0x2A - 0x2B', field: 'Aligned Height', type: 'uint16', val: `${ctex.height} px`, desc: 'Padded to 4x4 block multiple' },
            { offset: '0x2C - 0x2F', field: 'Mipmap Levels Count', type: 'uint32', val: ctex.mipmapCount, desc: 'Total downsampled mip levels' },
            { offset: '0x30 - 0x33', field: 'Godot Format Enum', type: 'uint32', val: `${ctex.formatId} (${ctex.formatName})`, desc: 'Target GPU pixel format' },
            { offset: '0x34 - EOF',  field: 'Payload Data Stream', type: 'byte[]', val: `${formatBytes(ctex.payloadSize)} (${ctex.payloadSize.toLocaleString()} B)`, desc: 'Compressed block sequence' }
        ];

        headerTableBody.innerHTML = rows.map(r => `
            <tr>
                <td><code>${r.offset}</code></td>
                <td><strong>${r.field}</strong></td>
                <td><small style="color: var(--text-muted);">${r.type}</small></td>
                <td><code style="color: #63b3ed;">${r.val}</code></td>
                <td><small>${r.desc}</small></td>
            </tr>
        `).join('');
    }

    function updateMipmapExplorer(ctex) {
        if (!ctex.mipLevels || ctex.mipLevels.length === 0) {
            mipsTableBody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted);">No mipmaps in texture</td></tr>`;
            return;
        }

        mipsTableBody.innerHTML = ctex.mipLevels.map(m => {
            const blocks = (m.paddedWidth * m.paddedHeight) / 16;
            const isSmeared = (m.width < 4 || m.height < 4);
            const smearNote = isSmeared ? `<span style="color: var(--accent-amber); font-weight: 600;">Smeared (${m.width}&times;${m.height} &rarr; 4&times;4)</span>` : 'Exact 4x4 block';

            return `
                <tr>
                    <td><strong>Level ${m.level}</strong></td>
                    <td>${m.width} &times; ${m.height}</td>
                    <td><code>${m.paddedWidth} &times; ${m.paddedHeight}</code></td>
                    <td>${blocks.toLocaleString()}</td>
                    <td>${m.byteLength.toLocaleString()} B</td>
                    <td>${formatBytes(m.byteLength)}</td>
                    <td>${smearNote}</td>
                </tr>
            `;
        }).join('');
    }

    // Load active pair (TGA & CTEX)
    async function loadActivePair(tgaUrl, ctexUrl) {
        try {
            const tgaRes = await fetch(tgaUrl);
            const tgaBuf = await tgaRes.arrayBuffer();
            currentTga = GodotTextureLoader.parseTGA(tgaBuf);

            const ctexRes = await fetch(ctexUrl);
            const ctexBuf = await ctexRes.arrayBuffer();
            currentCtex = GodotTextureLoader.parseCTEX(ctexBuf);

            // Update 2D Inspector
            renderRgbaToCanvas(canvasTga, currentTga.rgbaData, currentTga.width, currentTga.height);
            const rgbaCtex = GodotTextureLoader.decodeCTEXtoRGBA(currentCtex, 0);
            renderRgbaToCanvas(canvasCtex, rgbaCtex, currentCtex.width, currentCtex.height);

            tgaDim.textContent = `${currentTga.width} \u00D7 ${currentTga.height}`;
            tgaFilesize.textContent = formatBytes(currentTga.fileSize);
            tgaVram.textContent = `${formatBytes(currentTga.nominalVramWithMips)} (with mips)`;
            tgaFormatBadge.textContent = `${currentTga.bpp} bpp BGRA`;

            ctexFilesize.textContent = formatBytes(currentCtex.fileSize);
            ctexVram.textContent = `${formatBytes(currentCtex.nominalVram)} (-${((1 - currentCtex.nominalVram / currentTga.nominalVramWithMips) * 100).toFixed(0)}%)`;
            ctexFormatBadge.textContent = currentCtex.formatName;

            mipmapSlider.max = currentCtex.mipmapCount;
            mipmapSlider.value = 0;
            mipLabel.textContent = `0 (${currentCtex.width}x${currentCtex.height})`;

            updateHeaderInspector(currentCtex);
            updateMipmapExplorer(currentCtex);

            // Update 3D Materials & Cubes
            update3DMaterials();

        } catch (err) {
            console.error('Error loading texture pair:', err);
        }
    }

    // Mipmap slider in 2D
    mipmapSlider.addEventListener('input', (e) => {
        const lvl = parseInt(e.target.value, 10);
        if (currentCtex && currentCtex.mipLevels[lvl]) {
            const m = currentCtex.mipLevels[lvl];
            mipLabel.textContent = `${lvl} (${m.width}x${m.height})`;
            const rgba = GodotTextureLoader.decodeCTEXtoRGBA(currentCtex, lvl);
            renderRgbaToCanvas(canvasCtex, rgba, m.width, m.height);
        }
    });

    async function reloadTextures() {
        const presetId = presetSelect.value;
        const formatId = formatSelect.value;
        const preset = presetsData.find(p => p.id === presetId);
        if (!preset) return;

        currentPreset = preset;
        const tgaUrl = preset.tgaUrl;
        const ctexUrl = preset.ctexVariants[formatId] || preset.ctexVariants['etc2'];

        await loadActivePair(tgaUrl, ctexUrl);
    }

    presetSelect.addEventListener('change', reloadTextures);
    formatSelect.addEventListener('change', reloadTextures);

    // Tab buttons
    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const targetId = btn.getAttribute('data-tab');
            document.getElementById(targetId).classList.add('active');
        });
    });

    // Custom Upload Modal Controls
    btnOpenUpload.addEventListener('click', () => { uploadModal.style.display = 'flex'; });
    modalBtnCancel.addEventListener('click', () => { uploadModal.style.display = 'none'; });

    modalBtnSubmit.addEventListener('click', async () => {
        if (!modalFileInput.files || modalFileInput.files.length === 0) {
            alert('Please select an image file first.');
            return;
        }

        const file = modalFileInput.files[0];
        const mode = modalFormatSelect.value;
        const mipmaps = modalMipsSelect.value;

        const formData = new FormData();
        formData.append('image', file);
        formData.append('mode', mode);
        formData.append('mipmaps', mipmaps);

        modalBtnSubmit.textContent = 'Compressing...';
        modalBtnSubmit.disabled = true;

        try {
            const res = await fetch('/api/compress-custom', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || 'Server error');

            uploadModal.style.display = 'none';
            await loadActivePair(data.tgaUrl, data.ctexUrl);
        } catch (err) {
            alert(`Compression failed: ${err.message}`);
        } finally {
            modalBtnSubmit.textContent = 'Compress & Profile';
            modalBtnSubmit.disabled = false;
        }
    });

    // Init Three.js and Start Animation Loop
    initThreeScenes();
    buildCubes();
    animate();

    // Fetch initial presets
    try {
        const res = await fetch('/api/presets');
        presetsData = await res.json();
        await reloadTextures();
    } catch (err) {
        console.error('Failed to initialize presets:', err);
    }
});
