/**
 * server.js - Godot 4 CTEX vs TGA Web Comparison & Profiling Server
 */

const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/presets', express.static(path.join(__dirname, 'presets')));
app.use('/static', express.static(__dirname));

const upload = multer({ dest: path.join(__dirname, 'uploads') });
os_upload_dir = path.join(__dirname, 'uploads');
if (!fs.existsSync(os_upload_dir)) fs.mkdirSync(os_upload_dir, { recursive: true });

// API: Get available sample presets
app.get('/api/presets', (req, res) => {
    res.json([
        {
            id: 'game_ui',
            title: 'Game UI / Sprite (with Alpha)',
            description: '512x512 RPG inventory panel with transparency and sharp icons',
            tgaUrl: '/presets/game_ui.tga',
            pngUrl: '/presets/game_ui.png',
            ctexVariants: {
                etc2: '/presets/game_ui_etc2.ctex',
                dxt: '/presets/game_ui_dxt.ctex',
                lossless: '/presets/game_ui_lossless.ctex',
                lossy: '/presets/game_ui_lossy.ctex'
            }
        },
        {
            id: 'gradient_art',
            title: 'Vibrant Art / Gradient (Opaque RGB)',
            description: '512x512 high dynamic range color gradients with geometric details',
            tgaUrl: '/presets/gradient_art.tga',
            pngUrl: '/presets/gradient_art.png',
            ctexVariants: {
                etc2: '/presets/gradient_art_etc2.ctex',
                dxt: '/presets/gradient_art_dxt.ctex',
                lossless: '/presets/gradient_art_lossless.ctex',
                lossy: '/presets/gradient_art_lossy.ctex'
            }
        },
        {
            id: 'normal_map',
            title: 'Tangent Normal Map (Tangent Space RGB)',
            description: '512x512 normal vectors for 3D lighting bump simulation',
            tgaUrl: '/presets/normal_map.tga',
            pngUrl: '/presets/normal_map.png',
            ctexVariants: {
                etc2: '/presets/normal_map_etc2.ctex',
                dxt: '/presets/normal_map_dxt.ctex',
                lossless: '/presets/normal_map_lossless.ctex',
                lossy: '/presets/normal_map_lossy.ctex'
            }
        },
        {
            id: 'debug_mips',
            title: 'Color-Coded Mipmap Chain (Visual 3D Proof)',
            description: 'Pre-baked offline mip levels: L0=Red, L1=Orange, L2=Yellow, L3=Green, L4=Teal, L5=Blue',
            tgaUrl: '/presets/debug_mips.tga',
            pngUrl: '/presets/debug_mips.png',
            ctexVariants: {
                etc2: '/presets/debug_mips_etc2.ctex',
                dxt: '/presets/debug_mips_etc2.ctex',
                lossless: '/presets/debug_mips_etc2.ctex',
                lossy: '/presets/debug_mips_etc2.ctex'
            }
        }
    ]);
});

// API: Compress custom uploaded image on the fly using godot_ctex.py
app.post('/api/compress-custom', upload.single('image'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No image uploaded' });
        }

        const mode = req.body.mode || 'etc2';
        const mipmaps = req.body.mipmaps !== 'false';
        const quality = req.body.quality || 80;

        const inputPath = req.file.path;
        const outBase = path.join(os_upload_dir, req.file.filename);
        const ctexPath = `${outBase}.ctex`;
        const tgaPath = `${outBase}.tga`;

        // 1. Convert to TGA
        execSync(`python3 godot_ctex.py to_tga "${inputPath}" "${tgaPath}"`);

        // 2. Encode to CTEX
        const mipArg = mipmaps ? '--mipmaps' : '--no-mipmaps';
        execSync(`python3 godot_ctex.py encode "${inputPath}" "${ctexPath}" --mode ${mode} ${mipArg} --quality ${quality}`);

        res.json({
            success: true,
            tgaUrl: `/uploads/${req.file.filename}.tga`,
            ctexUrl: `/uploads/${req.file.filename}.ctex`,
            filename: req.file.originalname,
            mode: mode,
            mipmaps: mipmaps
        });
    } catch (err) {
        console.error('Compression error:', err);
        res.status(500).json({ error: err.message });
    }
});

// Serve uploads
app.use('/uploads', express.static(os_upload_dir));

// Redirect root to index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Godot 4 CTEX vs TGA Web Server running on http://0.0.0.0:${PORT}`);
});
