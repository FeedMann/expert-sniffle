#!/usr/bin/env python3
"""
create_debug_mips.py - Generates a texture with distinct color-coded mipmap levels
to visibly prove that Godot .ctex stores offline pre-baked mip levels,
unlike TGA which can only do naive hardware box-filtering at runtime.
"""

import os
from PIL import Image, ImageDraw
import numpy as np
import godot_ctex

# Colors for mip levels 0 through 9
MIP_COLORS = [
    (235, 50, 50),    # L0: 512x512 - Bright Red
    (245, 130, 32),   # L1: 256x256 - Orange
    (245, 210, 32),   # L2: 128x128 - Yellow
    (50, 205, 50),    # L3: 64x64   - Lime Green
    (32, 178, 170),   # L4: 32x32   - Teal
    (30, 144, 255),   # L5: 16x16   - Dodger Blue
    (138, 43, 226),   # L6: 8x8     - Purple
    (255, 20, 147),   # L7: 4x4     - Deep Pink
    (240, 240, 240),  # L8: 2x2     - White
    (180, 180, 180),  # L9: 1x1     - Grey
]

os.makedirs("presets", exist_ok=True)

# Generate base level image (512x512)
base_img = Image.new("RGBA", (512, 512), (28, 32, 45, 255))
draw = ImageDraw.Draw(base_img)
# Draw grid pattern & text
for x in range(0, 512, 32):
    draw.line([(x, 0), (x, 512)], fill=(45, 52, 70), width=1)
for y in range(0, 512, 32):
    draw.line([(0, y), (512, y)], fill=(45, 52, 70), width=1)
draw.rounded_rectangle([32, 32, 480, 480], radius=16, outline=MIP_COLORS[0], width=8)
draw.text((140, 240), "MIP 0: 512x512", fill=(255, 255, 255, 255))

base_img.save("presets/debug_mips.png")

# Now let's build the custom color-coded mipmap chain
mip_images = []
w, h = 512, 512
level = 0
while w >= 1 and h >= 1:
    color = MIP_COLORS[min(level, len(MIP_COLORS) - 1)]
    m_img = Image.new("RGBA", (w, h), (color[0], color[1], color[2], 255))
    d = ImageDraw.Draw(m_img)
    if w >= 32:
        d.rectangle([2, 2, w-3, h-3], outline=(255, 255, 255), width=max(1, w // 64))
    if w >= 64:
        d.text((w // 4, h // 2 - 6), f"MIP {level}", fill=(255, 255, 255))
    mip_images.append(m_img)
    if w == 1 and h == 1:
        break
    w = max(1, w >> 1)
    h = max(1, h >> 1)
    level += 1

print(f"Generated {len(mip_images)} color-coded mip levels.")

# Now encode to CTEX with these custom pre-baked mip levels!
import struct, etcpak
godot_format = godot_ctex.FORMAT_ETC2_RGBA8
compressed_payload = bytearray()
levels_info = []

for idx, m_img in enumerate(mip_images):
    mw, mh = m_img.size
    pad_w = (mw + 3) & ~3
    pad_h = (mh + 3) & ~3
    arr = np.array(m_img)
    padded = godot_ctex.pad_and_smear(arr, pad_w, pad_h)
    bgra = padded[:, :, [2, 1, 0, 3]].copy()
    block_data = etcpak.compress_etc2_rgba(bgra.tobytes(), pad_w, pad_h)
    levels_info.append((mw, mh, len(block_data)))
    compressed_payload.extend(block_data)

header = bytearray()
header.extend(godot_ctex.MAGIC)
header.extend(struct.pack("<I", godot_ctex.FORMAT_VERSION))
header.extend(struct.pack("<I", 512))
header.extend(struct.pack("<I", 512))
header.extend(struct.pack("<I", godot_ctex.FORMAT_BIT_HAS_MIPMAPS))
header.extend(struct.pack("<I", 0))
header.extend(struct.pack("<III", 0, 0, 0))

payload_header = bytearray()
payload_header.extend(struct.pack("<I", godot_ctex.DATA_FORMAT_IMAGE))
payload_header.extend(struct.pack("<H", 512))
payload_header.extend(struct.pack("<H", 512))
payload_header.extend(struct.pack("<I", len(mip_images) - 1))
payload_header.extend(struct.pack("<I", godot_format))

total_ctex = header + payload_header + compressed_payload
with open("presets/debug_mips_etc2.ctex", "wb") as f:
    f.write(total_ctex)

# Also save TGA (which can only store base level 0)
godot_ctex.save_to_tga("presets/debug_mips.png", "presets/debug_mips.tga")

print("Created presets/debug_mips_etc2.ctex and presets/debug_mips.tga successfully!")
